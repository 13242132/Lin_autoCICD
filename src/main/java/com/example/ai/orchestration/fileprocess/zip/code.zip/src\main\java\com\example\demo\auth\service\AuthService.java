package com.example.demo.auth.service;

import com.example.demo.auth.repository.AuthRepository;
import com.example.demo.auth.util.JwtUtil;
import com.example.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {
    @Autowired
    private AuthRepository authRepository;

    public Map<String, Object> login(String username, String password) {
        Optional<User> userOptional = authRepository.findByUsername(username);
        if (userOptional.isEmpty() || !userOptional.get().getPassword().equals(password)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid username or password");
        }

        Map<String, Object> response = new HashMap<>();
        response.put("token", JwtUtil.generateToken(username));
        return response;
    }

    public Map<String, Object> register(String username, String password) {
        if (authRepository.findByUsername(username).isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Username already exists");
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        authRepository.save(user);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "User registered successfully");
        return response;
    }

    public Map<String, Object> getCurrentUser(String username) {
        Map<String, Object> response = new HashMap<>();
        response.put("username", username);
        return response;
    }
}