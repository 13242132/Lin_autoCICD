// Class: Task
package com.example.demo.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.List;
import java.util.Set;
import lombok.Data;

@Data
@Entity
@Table(name = "task_tbl")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, length = 200)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "assignee", nullable = false, length = 20)
    private String assignee;

    @Column(name = "due_date", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime dueDate;

    @Column(name = "priority", nullable = false, length = 10)
    private String priority;

    @Column(name = "status", nullable = false, length = 20)
    private String status = "PENDING";

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime updatedAt;

    @ElementCollection
    @CollectionTable(
        name = "task_attachment_tbl",
        joinColumns = @JoinColumn(name = "task_id")
    )
    @Column(name = "attachment_url", length = 500)
    private List<String> attachments;

    @ElementCollection
    @CollectionTable(
        name = "task_comment_tbl",
        joinColumns = @JoinColumn(name = "task_id")
    )
    @Column(name = "comment", columnDefinition = "TEXT")
    private List<String> comments;

}