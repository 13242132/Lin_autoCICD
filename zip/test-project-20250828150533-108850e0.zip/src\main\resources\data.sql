-- ========================================
-- Table: user_tbl
-- 描述: 用户表
-- 字段:
-- id BIGINT 主键，自增
-- username VARCHAR(20) 用户名，不为空，唯一
-- password VARCHAR(100) 密码，不为空
-- email VARCHAR(100) 邮箱，可为空
-- full_name VARCHAR(50) 全名，可为空
-- status VARCHAR(20) 状态，不为空，默认 "ACTIVE"
-- role VARCHAR(20) 角色，不为空，默认 "USER"
-- created_at TIMESTAMP 创建时间，不为空
-- updated_at TIMESTAMP 更新时间，可为空
-- ========================================
MERGE INTO user_tbl (id, username, password, email, full_name, status, role, created_at, updated_at)
KEY(username)
VALUES (1, 'admin', 'admin123', 'admin@example.com', 'Admin User', 'ACTIVE', 'ADMIN', '2025-01-01 10:00:00', NULL);

MERGE INTO user_tbl (id, username, password, email, full_name, status, role, created_at, updated_at)
KEY(username)
VALUES (2, 'user1', 'user123', 'user1@example.com', 'User One', 'ACTIVE', 'USER', '2025-01-02 11:00:00', NULL);

MERGE INTO user_tbl (id, username, password, email, full_name, status, role, created_at, updated_at)
KEY(username)
VALUES (3, 'user2', 'user456', 'user2@example.com', 'User Two', 'INACTIVE', 'USER', '2025-01-03 12:00:00', '2025-01-04 14:00:00');

-- ========================================
-- Table: task_tbl
-- 描述: 任务表
-- 字段:
-- id BIGINT 主键，自增
-- title VARCHAR(200) 标题，不为空
-- description TEXT 描述，可为空
-- assignee VARCHAR(20) 被指派人，不为空
-- due_date TIMESTAMP 截止时间，不为空
-- priority VARCHAR(10) 优先级，不为空
-- status VARCHAR(20) 状态，不为空，默认 "PENDING"
-- created_at TIMESTAMP 创建时间，不为空
-- updated_at TIMESTAMP 更新时间，可为空
-- ========================================
MERGE INTO task_tbl (id, title, description, assignee, due_date, priority, status, created_at, updated_at)
KEY(title)
VALUES (1, 'Initial Task', 'This is the first task.', 'user1', '2025-01-10 18:00:00', 'HIGH', 'PENDING', '2025-01-05 09:00:00', NULL);

MERGE INTO task_tbl (id, title, description, assignee, due_date, priority, status, created_at, updated_at)
KEY(title)
VALUES (2, 'Urgent Bug Fix', 'Fix the critical bug in the system.', 'admin', '2025-01-08 17:00:00', 'CRITICAL', 'IN_PROGRESS', '2025-01-06 10:00:00', '2025-01-07 11:00:00');

-- ========================================
-- Table: task_attachment_tbl
-- 描述: 任务附件表（集合）
-- 字段:
-- task_id BIGINT 任务ID，外键
-- attachment_url VARCHAR(500) 附件链接
-- ========================================
MERGE INTO task_attachment_tbl (task_id, attachment_url)
KEY(task_id, attachment_url)
VALUES (1, 'http://example.com/files/initial-task.docx');

MERGE INTO task_attachment_tbl (task_id, attachment_url)
KEY(task_id, attachment_url)
VALUES (2, 'http://example.com/files/urgent-bug-report.pdf');

-- ========================================
-- Table: task_comment_tbl
-- 描述: 任务评论表（集合）
-- 字段:
-- task_id BIGINT 任务ID，外键
-- comment TEXT 评论内容
-- ========================================
MERGE INTO task_comment_tbl (task_id, comment)
KEY(task_id, comment)
VALUES (1, 'Need more details on this task.');

MERGE INTO task_comment_tbl (task_id, comment)
KEY(task_id, comment)
VALUES (2, 'This is a high-priority fix. Please resolve ASAP.');

-- ========================================
-- Table: audit_log_tbl
-- 描述: 审计日志表
-- 字段:
-- id BIGINT 主键，自增
-- user_id BIGINT 用户ID，不为空
-- action VARCHAR(50) 操作，不为空
-- targetType VARCHAR(50) 目标类型
-- target_id BIGINT 目标ID
-- details TEXT 详情
-- created_at TIMESTAMP 创建时间，不为空
-- ip_address VARCHAR(45) IP地址
-- ========================================
MERGE INTO audit_log_tbl (id, user_id, action, target_type, target_id, details, created_at, ip_address)
KEY(id)
VALUES (1, 1, 'LOGIN', 'USER', 1, 'User logged in successfully.', '2025-01-05 09:30:00', '192.168.1.1');

MERGE INTO audit_log_tbl (id, user_id, action, target_type, target_id, details, created_at, ip_address)
KEY(id)
VALUES (2, 2, 'CREATE_TASK', 'TASK', 1, 'Created new task: Initial Task', '2025-01-05 09:35:00', '192.168.1.2');

MERGE INTO audit_log_tbl (id, user_id, action, target_type, target_id, details, created_at, ip_address)
KEY(id)
VALUES (3, 1, 'UPDATE_TASK', 'TASK', 2, 'Updated task status to IN_PROGRESS', '2025-01-07 11:15:00', '192.168.1.1');