```java
basicInfo: 用户注册 POST /api/auth/register - 新用户注册账号
requestParams: { "username": "String, 必填 - 用户名，长度≤20", "email": "String, 必填 - 邮箱地址", "password": "String, 必填 - 密码，长度≥8" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","username":"String","email":"String","status":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"REGISTER_FAILED","message":"注册失败，邮箱已存在" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth
---API_SEPARATOR---
basicInfo: 用户登录 POST /api/auth/login - 用户登录系统
requestParams: { "username": "String, 必填 - 用户名或邮箱", "password": "String, 必填 - 密码" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "token":"String","user":{"id":"Long","username":"String","email":"String","avatar":"String"} } },
  "error": { "status_code": 401, "response_body": { "error":"LOGIN_FAILED","message":"用户名或密码错误" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth
---API_SEPARATOR---
basicInfo: 创建文章 POST /api/articles - 发布新文章
requestParams: { "title": "String, 必填 - 文章标题，长度≤100", "content": "String, 必填 - 文章内容，长度≥100", "tags": "List<String>, 可选 - 标签列表，最多5个" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","title":"String","content":"String","tags":["String"],"status":"String","createdAt":"LocalDateTime" } },
  "error": { "status_code": 400, "response_body": { "error":"CREATE_ARTICLE_FAILED","message":"创建文章失败" } }
}
apiType: entity_related
controller: ArticleController
basePath: /api/articles
---API_SEPARATOR---
basicInfo: 获取文章列表 GET /api/articles - 查询文章列表
requestParams: { "tag": "String, 可选 - 按标签筛选", "author": "String, 可选 - 按作者筛选", "page": "Integer, 可选 - 页码", "size": "Integer, 可选 - 每页数量" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","title":"String","content":"String","author":"String","tags":["String"],"createdAt":"LocalDateTime","viewCount":"Integer" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: ArticleController
basePath: /api/articles
---API_SEPARATOR---
basicInfo: 获取文章详情 GET /api/articles/{id} - 获取单篇文章详情
requestParams: { "id": "Long, 必填 - 文章ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","title":"String","content":"String","author":"String","tags":["String"],"createdAt":"LocalDateTime","viewCount":"Integer","comments":["Comment"] } },
  "error": { "status_code": 404, "response_body": { "error":"ARTICLE_NOT_FOUND","message":"文章不存在" } }
}
apiType: entity_related
controller: ArticleController
basePath: /api/articles
---API_SEPARATOR---
basicInfo: 搜索文章 GET /api/articles/search - 搜索文章
requestParams: { "keyword": "String, 必填 - 搜索关键词", "type": "String, 可选 - 搜索类型(文章/作者/标签)" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","title":"String","content":"String","author":"String","tags":["String"],"createdAt":"LocalDateTime" } ] },
  "error": { "status_code": 400, "response_body": { "error":"SEARCH_FAILED","message":"搜索失败" } }
}
apiType: entity_related
controller: ArticleController
basePath: /api/articles
---API_SEPARATOR---
basicInfo: 获取热门标签 GET /api/tags - 获取热门标签列表
requestParams: {}
responseParams: {
  "success": { "status_code": 200, "response_body": [ "String" ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: TagController
basePath: /api/tags
---API_SEPARATOR---
basicInfo: 获取用户个人资料 GET /api/users/profile - 获取当前用户个人资料
requestParams: {}
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","username":"String","email":"String","avatar":"String","bio":"String","createdAt":"LocalDateTime" } },
  "error": { "status_code": 401, "response_body": { "error":"UNAUTHORIZED","message":"未授权访问" } }
}
apiType: entity_related
controller: UserController
basePath: /api/users
---API_SEPARATOR---
basicInfo: 更新用户个人资料 PUT /api/users/profile - 更新用户个人资料
requestParams: { "email": "String, 可选 - 邮箱", "avatar": "String, 可选 - 头像URL", "bio": "String, 可选 - 个人简介" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","username":"String","email":"String","avatar":"String","bio":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"UPDATE_PROFILE_FAILED","message":"更新个人资料失败" } }
}
apiType: entity_related
controller: UserController
basePath: /api/users
---API_SEPARATOR---
basicInfo: 获取用户文章列表 GET /api/users/articles - 获取当前用户的文章列表
requestParams: { "status": "String, 可选 - 文章状态" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","title":"String","content":"String","tags":["String"],"status":"String","createdAt":"LocalDateTime" } ] },
  "error": { "status_code": 401, "response_body": { "error":"UNAUTHORIZED","message":"未授权访问" } }
}
apiType: entity_related
controller: UserController
basePath: /api/users
---API_SEPARATOR---
basicInfo: 添加评论 POST /api/articles/{id}/comments - 为文章添加评论
requestParams: { "content": "String, 必填 - 评论内容", "articleId": "Long, 必填 - 文章ID" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","content":"String","author":"String","createdAt":"LocalDateTime" } },
  "error": { "status_code": 400, "response_body": { "error":"ADD_COMMENT_FAILED","message":"添加评论失败" } }
}
apiType: entity_related
controller: CommentController
basePath: /api/articles
---API_SEPARATOR---
basicInfo: 获取管理员仪表盘数据 GET /api/admin/dashboard - 获取管理员仪表盘统计数据
requestParams: {}
responseParams: {
  "success": { "status_code": 200, "response_body": { "totalUsers":"Integer","pendingArticles":"Integer","activeUsersToday":"Integer","totalComments":"Integer" } },
  "error": { "status_code": 403, "response_body": { "error":"FORBIDDEN","message":"无权限访问" } }
}
apiType: business_related
controller: AdminController
basePath: /api/admin
---API_SEPARATOR---
---ENTITY_LIST_START---
@Table(name = "user_account_tbl")
public class UserAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "username", nullable = false, length = 20)
    private String username;

    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Column(name = "password", nullable = false, length = 100)
    private String password;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "last_login_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastLoginAt;
}

@Table(name = "user_profile_tbl")
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "avatar", length = 255)
    private String avatar;

    @Column(name = "bio", length = 500)
    private String bio;

    @Column(name = "updated_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime updatedAt = LocalDateTime.now();
}

@Table(name = "article_post_tbl")
public class ArticlePost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, length = 100)
    private String title;

    @Column(name = "content", nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(name = "author_id", nullable = false)
    private Long authorId;

    @Column(name = "author_name", nullable = false, length = 20)
    private String authorName;

    @ElementCollection
    @CollectionTable(
        name = "article_tag_tbl",
        joinColumns = @JoinColumn(name = "article_id")
    )
    @Column(name = "tag", length = 20)
    private List<String> tags;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "view_count", nullable = false)
    private Integer viewCount = 0;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime updatedAt = LocalDateTime.now();
}

@Table(name = "comment_thread_tbl")
public class CommentThread {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "article_id", nullable = false)
    private Long articleId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "user_name", nullable = false, length = 20)
    private String userName;

    @Column(name = "content", nullable = false, length = 1000)
    private String content;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "tag_group_tbl")
public class TagGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", nullable = false, length = 20)
    private String name;

    @Column(name = "usage_count", nullable = false)
    private Integer usageCount = 0;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "notification_tbl")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "type", nullable = false, length = 50)
    private String type;

    @Column(name = "title", nullable = false, length = 100)
    private String title;

    @Column(name = "content", nullable = false, length = 500)
    private String content;

    @Column(name = "is_read", nullable = false)
    private Boolean isRead = false;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}
---ENTITY_LIST_END---
```