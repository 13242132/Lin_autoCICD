package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class test_project_20250828153820_0f94a1abApplication {

    public static void main(String[] args) {
        SpringApplication.run(test_project_20250828153820_0f94a1abApplication.class, args);
    }

}