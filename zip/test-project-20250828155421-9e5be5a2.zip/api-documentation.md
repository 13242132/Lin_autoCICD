# 接口文档标准化输出

basicInfo: 用户注册 POST /api/auth/register - 创建新用户账号
requestParams: { "username": "String, 必填 - 用户名", "password": "String, 必填 - 密码" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","username":"String","message":"注册成功" } },
  "error": { "status_code": 400, "response_body": { "error":"USERNAME_EXISTS","message":"用户名已存在" } },
  "error": { "status_code": 400, "response_body": { "error":"PASSWORD_WEAK","message":"密码强度不足" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

basicInfo: 用户登录 POST /api/auth/login - 用户登录认证
requestParams: { "username": "String, 必填 - 用户名", "password": "String, 必填 - 密码", "rememberMe": "Boolean, 可选 - 记住我" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "token":"String","userId":"Long","username":"String" } },
  "error": { "status_code": 401, "response_body": { "error":"INVALID_CREDENTIALS","message":"用户名或密码错误" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

basicInfo: 获取新闻频道列表 GET /api/news-channels - 查询所有新闻频道
requestParams: { "category": "String, 可选 - 频道分类", "search": "String, 可选 - 搜索关键词" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","name":"String","description":"String","category":"String","sourceUrl":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: NewsChannelController
basePath: /api/news-channels

---API_SEPARATOR---

basicInfo: 订阅新闻频道 POST /api/subscriptions - 用户订阅新闻频道
requestParams: { "userId": "Long, 必填 - 用户ID", "channelId": "Long, 必填 - 频道ID" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","userId":"Long","channelId":"Long","subscribedAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"CHANNEL_NOT_FOUND","message":"频道不存在" } },
  "error": { "status_code": 400, "response_body": { "error":"ALREADY_SUBSCRIBED","message":"已订阅该频道" } }
}
apiType: entity_related
controller: SubscriptionController
basePath: /api/subscriptions

---API_SEPARATOR---

basicInfo: 取消订阅 DELETE /api/subscriptions/{id} - 用户取消订阅
requestParams: { "id": "Long, 必填 - 订阅ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "message":"取消订阅成功" } },
  "error": { "status_code": 404, "response_body": { "error":"SUBSCRIPTION_NOT_FOUND","message":"订阅记录不存在" } }
}
apiType: entity_related
controller: SubscriptionController
basePath: /api/subscriptions

---API_SEPARATOR---

basicInfo: 获取用户订阅列表 GET /api/subscriptions/user/{userId} - 查询用户的所有订阅
requestParams: { "userId": "Long, 必填 - 用户ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","userId":"Long","channelId":"Long","channelName":"String","channelDescription":"String","subscribedAt":"String" } ] },
  "error": { "status_code": 404, "response_body": { "error":"USER_NOT_FOUND","message":"用户不存在" } }
}
apiType: entity_related
controller: SubscriptionController
basePath: /api/subscriptions

---API_SEPARATOR---

basicInfo: 获取新闻列表 GET /api/news-items - 查询新闻条目
requestParams: { "channelId": "Long, 可选 - 频道ID", "page": "Integer, 可选 - 页码", "size": "Integer, 可选 - 每页大小", "search": "String, 可选 - 搜索关键词" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "content": [ { "id":"Long","title":"String","content":"String","source":"String","publishTime":"String","channelId":"Long" } ], "totalPages": "Integer", "totalElements": "Long" } },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: NewsItemController
basePath: /api/news-items

---API_SEPARATOR---

basicInfo: 获取新闻详情 GET /api/news-items/{id} - 获取单条新闻详情
requestParams: { "id": "Long, 必填 - 新闻ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","title":"String","content":"String","source":"String","publishTime":"String","channelId":"Long","channelName":"String" } },
  "error": { "status_code": 404, "response_body": { "error":"NEWS_NOT_FOUND","message":"新闻不存在" } }
}
apiType: entity_related
controller: NewsItemController
basePath: /api/news-items

---API_SEPARATOR---

basicInfo: 搜索新闻 GET /api/news-items/search - 搜索新闻内容
requestParams: { "keyword": "String, 必填 - 搜索关键词", "channel": "String, 可选 - 频道分类", "page": "Integer, 可选 - 页码", "size": "Integer, 可选 - 每页大小" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "content": [ { "id":"Long","title":"String","content":"String","source":"String","publishTime":"String","channelId":"Long" } ], "totalPages": "Integer", "totalElements": "Long" } },
  "error": { "status_code": 400, "response_body": { "error":"KEYWORD_REQUIRED","message":"搜索关键词不能为空" } }
}
apiType: business_related
controller: SearchController
basePath: /api/news-items/search

---API_SEPARATOR---

basicInfo: 用户登出 POST /api/auth/logout - 用户退出登录
requestParams: { "token": "String, 必填 - JWT令牌" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "message":"登出成功" } },
  "error": { "status_code": 400, "response_body": { "error":"INVALID_TOKEN","message":"无效的令牌" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

---ENTITY_LIST_START---
@Table(name = "user_profile_tbl")
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "username", nullable = false, length = 50, unique = true)
    private String username;

    @Column(name = "password", nullable = false, length = 100)
    private String password;

    @Column(name = "email", length = 100)
    private String email;

    @Column(name = "status", nullable = false, length = 20)
    private String status = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "last_login_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastLoginAt;
}

@Table(name = "news_channel_tbl")
public class NewsChannel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "category", nullable = false, length = 50)
    private String category;

    @Column(name = "source_url", nullable = false, length = 255)
    private String sourceUrl;

    @Column(name = "status", nullable = false, length = 20)
    private String status = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "subscription_tbl")
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "channel_id", nullable = false)
    private Long channelId;

    @Column(name = "subscribed_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime subscribedAt = LocalDateTime.now();

    @Column(name = "status", nullable = false, length = 20)
    private String status = "ACTIVE";
}

@Table(name = "news_item_tbl")
public class NewsItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, length = 200)
    private String title;

    @Column(name = "content", nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(name = "source", nullable = false, length = 100)
    private String source;

    @Column(name = "channel_id", nullable = false)
    private Long channelId;

    @Column(name = "publish_time", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime publishTime;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "image_url", length = 255)
    private String imageUrl;
}
---ENTITY_LIST_END---