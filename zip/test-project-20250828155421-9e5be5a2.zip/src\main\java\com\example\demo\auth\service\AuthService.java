package com.example.demo.auth.service;

import com.example.demo.auth.repository.AuthRepository;
import com.example.demo.auth.util.JwtUtil;
import com.example.demo.entity.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private AuthRepository authRepository;

    public Map<String, Object> login(String username, String password, Boolean rememberMe) {
        Optional<UserProfile> userOptional = authRepository.findByUsername(username);
        
        if (userOptional.isEmpty() || !userOptional.get().getPassword().equals(password)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户名或密码错误");
        }

        UserProfile user = userOptional.get();
        user.setLastLoginAt(LocalDateTime.now());
        authRepository.save(user);

        String token = JwtUtil.generateToken(username);
        
        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("userId", user.getId());
        response.put("username", user.getUsername());
        return response;
    }

    public Map<String, Object> register(String username, String password) {
        Optional<UserProfile> existingUser = authRepository.findByUsername(username);
        if (existingUser.isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "用户名已存在");
        }

        if (password == null || password.length() < 6) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "密码强度不足");
        }

        UserProfile newUser = new UserProfile();
        newUser.setUsername(username);
        newUser.setPassword(password);
        newUser.setStatus("ACTIVE");
        newUser.setCreatedAt(LocalDateTime.now());
        
        UserProfile savedUser = authRepository.save(newUser);
        
        Map<String, Object> response = new HashMap<>();
        response.put("id", savedUser.getId());
        response.put("username", savedUser.getUsername());
        response.put("message", "注册成功");
        return response;
    }

    public Map<String, Object> getCurrentUser(String username) {
        Optional<UserProfile> userOptional = authRepository.findByUsername(username);
        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户不存在");
        }

        UserProfile user = userOptional.get();
        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("email", user.getEmail());
        response.put("status", user.getStatus());
        return response;
    }

    public Map<String, Object> logout(String token) {
        try {
            String username = JwtUtil.getUsernameFromToken(token);
            if (username == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "无效的令牌");
            }
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "登出成功");
            return response;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "无效的令牌");
        }
    }
}