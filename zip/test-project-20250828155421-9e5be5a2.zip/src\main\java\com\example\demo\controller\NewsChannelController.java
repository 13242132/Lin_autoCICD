package com.example.demo.controller;

import com.example.demo.entity.NewsChannel;
import com.example.demo.service.NewsChannelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news-channels")
public class NewsChannelController {

    @Autowired
    private NewsChannelService newsChannelService;

    @GetMapping
    public ResponseEntity<?> getNewsChannels(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String search) {
        
        try {
            List<NewsChannel> channels = newsChannelService.getNewsChannels(category, search);
            return ResponseEntity.ok(channels);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                new ErrorResponse("INTERNAL_ERROR", "服务器错误")
            );
        }
    }

    // 错误响应类
    private static class ErrorResponse {
        private String error;
        private String message;

        public ErrorResponse(String error, String message) {
            this.error = error;
            this.message = message;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}