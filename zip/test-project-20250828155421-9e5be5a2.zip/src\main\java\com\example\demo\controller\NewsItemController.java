package com.example.demo.controller;

import com.example.demo.entity.NewsItem;
import com.example.demo.service.NewsItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import java.util.*;

@RestController
@RequestMapping("/api/news-items")
public class NewsItemController {

    @Autowired
    private NewsItemService newsItemService;

    @GetMapping
    public ResponseEntity<?> getNewsItems(
            @RequestParam(required = false) Long channelId,
            @RequestParam(required = false, defaultValue = "0") Integer page,
            @RequestParam(required = false, defaultValue = "10") Integer size,
            @RequestParam(required = false) String search) {
        
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<NewsItem> newsItemPage = newsItemService.getNewsItems(channelId, search, pageable);
            
            Map<String, Object> response = new HashMap<>();
            response.put("content", newsItemPage.getContent());
            response.put("totalPages", newsItemPage.getTotalPages());
            response.put("totalElements", newsItemPage.getTotalElements());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "INTERNAL_ERROR");
            errorResponse.put("message", "服务器错误");
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getNewsItemById(@PathVariable Long id) {
        try {
            Optional<NewsItem> newsItem = newsItemService.getNewsItemById(id);
            
            if (newsItem.isPresent()) {
                // 这里需要获取频道名称，但由于实体中没有关联关系，暂时返回null
                // 实际项目中应该通过关联查询获取频道名称
                Map<String, Object> response = new HashMap<>();
                NewsItem item = newsItem.get();
                response.put("id", item.getId());
                response.put("title", item.getTitle());
                response.put("content", item.getContent());
                response.put("source", item.getSource());
                response.put("publishTime", item.getPublishTime());
                response.put("channelId", item.getChannelId());
                response.put("channelName", null); // 频道名称需要额外查询
                
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("error", "NEWS_NOT_FOUND");
                errorResponse.put("message", "新闻不存在");
                return ResponseEntity.status(404).body(errorResponse);
            }
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "INTERNAL_ERROR");
            errorResponse.put("message", "服务器错误");
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
}