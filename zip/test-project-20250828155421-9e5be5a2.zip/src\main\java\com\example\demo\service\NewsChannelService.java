package com.example.demo.service;

import com.example.demo.entity.NewsChannel;
import com.example.demo.repository.NewsChannelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import jakarta.persistence.criteria.Predicate;

@Service
public class NewsChannelService {

    @Autowired
    private NewsChannelRepository newsChannelRepository;

    public List<NewsChannel> getNewsChannels(String category, String search) {
        Specification<NewsChannel> spec = Specification.where(null);
        
        if (StringUtils.hasText(category)) {
            spec = spec.and((root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("category"), category));
        }
        
        if (StringUtils.hasText(search)) {
            spec = spec.and((root, query, criteriaBuilder) -> 
                criteriaBuilder.or(
                    criteriaBuilder.like(root.get("name"), "%" + search + "%"),
                    criteriaBuilder.like(root.get("description"), "%" + search + "%")
                ));
        }
        
        spec = spec.and((root, query, criteriaBuilder) -> 
            criteriaBuilder.equal(root.get("status"), "ACTIVE"));
        
        return newsChannelRepository.findAll(spec);
    }
}