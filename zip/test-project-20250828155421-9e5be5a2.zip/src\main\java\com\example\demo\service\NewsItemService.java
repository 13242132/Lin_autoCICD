package com.example.demo.service;

import com.example.demo.entity.NewsItem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import jakarta.persistence.criteria.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.demo.repository.NewsItemRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.*;

@Service
public class NewsItemService {

    @Autowired
    private NewsItemRepository newsItemRepository;

    public Page<NewsItem> getNewsItems(Long channelId, String search, Pageable pageable) {
        Specification<NewsItem> spec = (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            
            if (channelId != null) {
                predicates.add(criteriaBuilder.equal(root.get("channelId"), channelId));
            }
            
            if (search != null && !search.trim().isEmpty()) {
                Predicate titlePredicate = criteriaBuilder.like(root.get("title"), "%" + search + "%");
                Predicate contentPredicate = criteriaBuilder.like(root.get("content"), "%" + search + "%");
                predicates.add(criteriaBuilder.or(titlePredicate, contentPredicate));
            }
            
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
        
        return newsItemRepository.findAll(spec, pageable);
    }

    public Optional<NewsItem> getNewsItemById(Long id) {
        return newsItemRepository.findById(id);
    }
}