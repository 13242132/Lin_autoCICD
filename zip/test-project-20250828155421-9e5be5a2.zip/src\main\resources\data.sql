-- ========================================
-- Table: user_profile_tbl
-- Description: 用户资料表
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- username VARCHAR(50) NOT NULL, UNIQUE
-- password VARCHAR(100) NOT NULL
-- email VARCHAR(100) NULL
-- status VARCHAR(20) NOT NULL
-- created_at TIMESTAMP NOT NULL
-- last_login_at TIMESTAMP NULL
-- ========================================
MERGE INTO user_profile_tbl (id, username, password, email, status, created_at, last_login_at)
KEY(username)
VALUES (1, 'admin', 'admin123', 'admin@example.com', 'ACTIVE', '2025-01-01 10:00:00', '2025-04-01 08:30:00');
MERGE INTO user_profile_tbl (id, username, password, email, status, created_at, last_login_at)
KEY(username)
VALUES (2, 'john_doe', 'user123', 'john@example.com', 'ACTIVE', '2025-01-02 11:00:00', '2025-04-02 09:15:00');
MERGE INTO user_profile_tbl (id, username, password, email, status, created_at, last_login_at)
KEY(username)
VALUES (3, 'jane_doe', 'user456', 'jane@example.com', 'INACTIVE', '2025-01-03 12:00:00', '2025-03-20 14:45:00');

-- ========================================
-- Table: news_channel_tbl
-- Description: 新闻频道表
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- name VARCHAR(100) NOT NULL
-- description VARCHAR(500) NULL
-- category VARCHAR(50) NOT NULL
-- source_url VARCHAR(255) NOT NULL
-- status VARCHAR(20) NOT NULL
-- created_at TIMESTAMP NOT NULL
-- ========================================
MERGE INTO news_channel_tbl (id, name, description, category, source_url, status, created_at)
KEY(name)
VALUES (1, 'TechCrunch', '科技新闻来源', '科技', 'https://techcrunch.com/feed', 'ACTIVE', '2025-01-01 09:00:00');
MERGE INTO news_channel_tbl (id, name, description, category, source_url, status, created_at)
KEY(name)
VALUES (2, 'BBC Sports', '体育新闻来源', '体育', 'https://bbc.com/sports', 'ACTIVE', '2025-01-02 09:30:00');
MERGE INTO news_channel_tbl (id, name, description, category, source_url, status, created_at)
KEY(name)
VALUES (3, '健康资讯网', '健康与生活资讯', '健康', 'https://healthnews.com', 'INACTIVE', '2025-01-03 10:00:00');

-- ========================================
-- Table: subscription_tbl
-- Description: 用户订阅表
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- user_id BIGINT NOT NULL
-- channel_id BIGINT NOT NULL
-- subscribed_at TIMESTAMP NOT NULL
-- status VARCHAR(20) NOT NULL
-- ========================================
MERGE INTO subscription_tbl (id, user_id, channel_id, subscribed_at, status)
KEY(user_id, channel_id)
VALUES (1, 2, 1, '2025-02-01 10:00:00', 'ACTIVE');
MERGE INTO subscription_tbl (id, user_id, channel_id, subscribed_at, status)
KEY(user_id, channel_id)
VALUES (2, 2, 2, '2025-02-02 11:00:00', 'ACTIVE');
MERGE INTO subscription_tbl (id, user_id, channel_id, subscribed_at, status)
KEY(user_id, channel_id)
VALUES (3, 3, 3, '2025-02-03 12:00:00', 'INACTIVE');

-- ========================================
-- Table: news_item_tbl
-- Description: 新闻条目表
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- title VARCHAR(200) NOT NULL
-- content TEXT NOT NULL
-- source VARCHAR(100) NOT NULL
-- channel_id BIGINT NOT NULL
-- publish_time TIMESTAMP NOT NULL
-- created_at TIMESTAMP NOT NULL
-- image_url VARCHAR(255) NULL
-- ========================================
MERGE INTO news_item_tbl (id, title, content, source, channel_id, publish_time, created_at, image_url)
KEY(title)
VALUES (1, 'AI技术新突破', '科学家在人工智能领域取得重大进展...', 'TechCrunch', 1, '2025-03-01 08:00:00', '2025-03-01 08:05:00', 'https://example.com/ai.jpg');
MERGE INTO news_item_tbl (id, title, content, source, channel_id, publish_time, created_at, image_url)
KEY(title)
VALUES (2, '世界杯决赛即将开赛', '全球瞩目的足球赛事决赛即将举行...', 'BBC Sports', 2, '2025-03-15 18:00:00', '2025-03-15 18:05:00', 'https://example.com/soccer.jpg');
MERGE INTO news_item_tbl (id, title, content, source, channel_id, publish_time, created_at, image_url)
KEY(title)
VALUES (3, '健康饮食建议', '专家推荐的健康饮食搭配指南...', '健康资讯网', 3, '2025-03-20 09:00:00', '2025-03-20 09:05:00', 'https://example.com/health.jpg');