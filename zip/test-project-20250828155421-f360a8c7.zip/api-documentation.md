根据提供的接口文档，我已经按照规则进行了标准化处理，确保输出文档完全符合工程级规范要求。以下是最终输出的合规接口文档与实体定义：

---

// 第1个接口  
basicInfo: 用户注册 POST /api/auth/register - 用户注册账号  
requestParams: { "username": "String, 必填 - 用户名，至少6个字符", "password": "String, 必填 - 密码，至少8个字符", "confirmPassword": "String, 必填 - 确认密码" }  
responseParams: {  
  "success": { "status_code": 201, "response_body": { "id": "Long", "username": "String", "message": "注册成功" } },  
  "error": {  
    "status_code": 400,  
    "response_body": {  
      "error": "REGISTRATION_FAILED",  
      "message": "注册失败原因：用户名已存在/密码不一致/用户名长度不足"  
    }  
  }  
}  
apiType: auth_related  
controller: AuthController  
basePath: /api/auth  

---API_SEPARATOR---

// 第2个接口  
basicInfo: 用户登录 POST /api/auth/login - 用户登录系统  
requestParams: { "username": "String, 必填 - 用户名", "password": "String, 必填 - 密码" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": { "id": "Long", "username": "String", "token": "String", "message": "登录成功" } },  
  "error": {  
    "status_code": 401,  
    "response_body": {  
      "error": "LOGIN_FAILED",  
      "message": "用户名或密码错误"  
    }  
  }  
}  
apiType: auth_related  
controller: AuthController  
basePath: /api/auth  

---API_SEPARATOR---

// 第3个接口  
basicInfo: 创建任务 POST /api/tasks - 创建新任务  
requestParams: { "title": "String, 必填 - 任务标题", "description": "String, 可选 - 任务描述", "deadline": "LocalDateTime, 必填 - 截止时间", "priority": "String, 必填 - 优先级(Low/Medium/High)", "assignee": "String, 可选 - 指派人" }  
responseParams: {  
  "success": { "status_code": 201, "response_body": { "id": "Long", "title": "String", "description": "String", "deadline": "LocalDateTime", "priority": "String", "assignee": "String", "status": "String", "createdAt": "LocalDateTime" } },  
  "error": {  
    "status_code": 400,  
    "response_body": {  
      "error": "TASK_CREATION_FAILED",  
      "message": "任务创建失败：标题为空/截止时间早于当前时间"  
    }  
  }  
}  
apiType: entity_related  
controller: TaskController  
basePath: /api/tasks  

---API_SEPARATOR---

// 第4个接口  
basicInfo: 获取任务列表 GET /api/tasks - 查询任务列表  
requestParams: { "status": "String, 可选 - 任务状态", "priority": "String, 可选 - 优先级", "assignee": "String, 可选 - 指派人" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": [ { "id": "Long", "title": "String", "description": "String", "deadline": "LocalDateTime", "priority": "String", "assignee": "String", "status": "String", "createdAt": "LocalDateTime" } ] },  
  "error": { "status_code": 500, "response_body": { "error": "INTERNAL_ERROR", "message": "服务器错误" } }  
}  
apiType: entity_related  
controller: TaskController  
basePath: /api/tasks  

---API_SEPARATOR---

// 第5个接口  
basicInfo: 获取任务详情 GET /api/tasks/{id} - 获取指定任务详情  
requestParams: { "id": "Long, 必填 - 任务ID" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": { "id": "Long", "title": "String", "description": "String", "deadline": "LocalDateTime", "priority": "String", "assignee": "String", "status": "String", "createdAt": "LocalDateTime", "comments": "List<Comment>" } },  
  "error": { "status_code": 404, "response_body": { "error": "TASK_NOT_FOUND", "message": "任务不存在" } }  
}  
apiType: entity_related  
controller: TaskController  
basePath: /api/tasks  

---API_SEPARATOR---

// 第6个接口  
basicInfo: 更新任务 PUT /api/tasks/{id} - 更新任务信息  
requestParams: { "id": "Long, 必填 - 任务ID", "title": "String, 可选 - 任务标题", "description": "String, 可选 - 任务描述", "deadline": "LocalDateTime, 可选 - 截止时间", "priority": "String, 可选 - 优先级", "assignee": "String, 可选 - 指派人", "status": "String, 可选 - 状态" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": { "id": "Long", "title": "String", "description": "String", "deadline": "LocalDateTime", "priority": "String", "assignee": "String", "status": "String", "updatedAt": "LocalDateTime" } },  
  "error": { "status_code": 400, "response_body": { "error": "UPDATE_FAILED", "message": "更新失败" } }  
}  
apiType: entity_related  
controller: TaskController  
basePath: /api/tasks  

---API_SEPARATOR---

// 第7个接口  
basicInfo: 删除任务 DELETE /api/tasks/{id} - 删除指定任务  
requestParams: { "id": "Long, 必填 - 任务ID" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": { "message": "任务删除成功" } },  
  "error": { "status_code": 404, "response_body": { "error": "TASK_NOT_FOUND", "message": "任务不存在" } }  
}  
apiType: entity_related  
controller: TaskController  
basePath: /api/tasks  

---API_SEPARATOR---

// 第8个接口  
basicInfo: 添加评论 POST /api/tasks/{id}/comments - 为任务添加评论  
requestParams: { "id": "Long, 必填 - 任务ID", "content": "String, 必填 - 评论内容", "author": "String, 必填 - 评论作者" }  
responseParams: {  
  "success": { "status_code": 201, "response_body": { "id": "Long", "content": "String", "author": "String", "createdAt": "LocalDateTime", "taskId": "Long" } },  
  "error": { "status_code": 400, "response_body": { "error": "COMMENT_FAILED", "message": "评论添加失败" } }  
}  
apiType: entity_related  
controller: TaskController  
basePath: /api/tasks  

---API_SEPARATOR---

// 第9个接口  
basicInfo: 修改密码 PUT /api/auth/password - 修改用户密码  
requestParams: { "oldPassword": "String, 必填 - 旧密码", "newPassword": "String, 必填 - 新密码", "confirmPassword": "String, 必填 - 确认新密码" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": { "message": "密码修改成功" } },  
  "error": { "status_code": 400, "response_body": { "error": "PASSWORD_CHANGE_FAILED", "message": "密码修改失败：旧密码错误/新密码不一致" } }  
}  
apiType: auth_related  
controller: AuthController  
basePath: /api/auth  

---API_SEPARATOR---

// 第10个接口  
basicInfo: 获取用户统计 GET /api/users/{id}/stats - 获取用户任务统计  
requestParams: { "id": "Long, 必填 - 用户ID" }  
responseParams: {  
  "success": { "status_code": 200, "response_body": { "totalTasks": "Integer", "completedTasks": "Integer", "pendingTasks": "Integer", "completionRate": "BigDecimal" } },  
  "error": { "status_code": 404, "response_body": { "error": "USER_NOT_FOUND", "message": "用户不存在" } }  
}  
apiType: entity_related  
controller: UserController  
basePath: /api/users  

---API_SEPARATOR---

---ENTITY_LIST_START---  
@Table(name = "user_tbl")  
public class User {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    @Column(name = "id")  
    private Long id;  

    @Column(name = "username", nullable = false, length = 50)  
    private String username;  

    @Column(name = "password", nullable = false, length = 100)  
    private String password;  

    @Column(name = "email", length = 100)  
    private String email;  

    @Column(name = "role", nullable = false, length = 20)  
    private String role;  

    @Column(name = "status", nullable = false, length = 20)  
    private String status;  

    @Column(name = "created_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime createdAt = LocalDateTime.now();  

    @Column(name = "updated_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime updatedAt = LocalDateTime.now();  
}  

@Table(name = "task_tbl")  
public class Task {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    @Column(name = "id")  
    private Long id;  

    @Column(name = "title", nullable = false, length = 200)  
    private String title;  

    @Column(name = "description", length = 1000)  
    private String description;  

    @Column(name = "deadline", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime deadline;  

    @Column(name = "priority", nullable = false, length = 20)  
    private String priority;  

    @Column(name = "assignee", length = 50)  
    private String assignee;  

    @Column(name = "status", nullable = false, length = 20)  
    private String status;  

    @Column(name = "created_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime createdAt = LocalDateTime.now();  

    @Column(name = "updated_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime updatedAt = LocalDateTime.now();  

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL)  
    private List<Comment> comments;  
}  

@Table(name = "comment_tbl")  
public class Comment {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    @Column(name = "id")  
    private Long id;  

    @Column(name = "content", nullable = false, length = 500)  
    private String content;  

    @Column(name = "author", nullable = false, length = 50)  
    private String author;  

    @ManyToOne  
    @JoinColumn(name = "task_id", nullable = false)  
    private Task task;  

    @Column(name = "created_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime createdAt = LocalDateTime.now();  
}  

@Table(name = "team_tbl")  
public class Team {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    @Column(name = "id")  
    private Long id;  

    @Column(name = "name", nullable = false, length = 100)  
    private String name;  

    @Column(name = "description", length = 500)  
    private String description;  

    @ElementCollection  
    @CollectionTable(  
        name = "team_member_tbl",  
        joinColumns = @JoinColumn(name = "team_id")  
    )  
    @Column(name = "member_name", length = 50)  
    private List<String> members;  

    @Column(name = "created_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime createdAt = LocalDateTime.now();  
}  

@Table(name = "notification_tbl")  
public class Notification {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    @Column(name = "id")  
    private Long id;  

    @Column(name = "title", nullable = false, length = 200)  
    private String title;  

    @Column(name = "content", nullable = false, length = 500)  
    private String content;  

    @Column(name = "recipient", nullable = false, length = 50)  
    private String recipient;  

    @Column(name = "type", nullable = false, length = 20)  
    private String type;  

    @Column(name = "is_read", nullable = false)  
    private Boolean isRead = false;  

    @Column(name = "created_at", nullable = false)  
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")  
    private LocalDateTime createdAt = LocalDateTime.now();  
}  
---ENTITY_LIST_END---