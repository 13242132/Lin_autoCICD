package com.example.demo.auth.service;

import com.example.demo.auth.repository.AuthRepository;
import com.example.demo.auth.util.JwtUtil;
import com.example.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private AuthRepository authRepository;

    public Map<String, Object> login(String username, String password) {
        Optional<User> userOptional = authRepository.findByUsername(username);
        
        if (userOptional.isEmpty() || !userOptional.get().getPassword().equals(password)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户名或密码错误");
        }

        User user = userOptional.get();
        String token = JwtUtil.generateToken(username);

        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("token", token);
        response.put("message", "登录成功");
        
        return response;
    }

    public Map<String, Object> register(String username, String password, String confirmPassword) {
        // 验证用户名长度
        if (username.length() < 6) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "用户名至少需要6个字符");
        }

        // 验证密码长度
        if (password.length() < 8) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "密码至少需要8个字符");
        }

        // 验证密码一致性
        if (!password.equals(confirmPassword)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "密码和确认密码不一致");
        }

        // 检查用户名是否已存在
        if (authRepository.findByUsername(username).isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "用户名已存在");
        }

        // 创建新用户
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setRole("USER");
        user.setStatus("ACTIVE");
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        User savedUser = authRepository.save(user);

        Map<String, Object> response = new HashMap<>();
        response.put("id", savedUser.getId());
        response.put("username", savedUser.getUsername());
        response.put("message", "注册成功");
        
        return response;
    }

    public Map<String, Object> changePassword(String username, String oldPassword, String newPassword, String confirmPassword) {
        Optional<User> userOptional = authRepository.findByUsername(username);
        
        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "用户不存在");
        }

        User user = userOptional.get();

        // 验证旧密码
        if (!user.getPassword().equals(oldPassword)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "旧密码错误");
        }

        // 验证新密码长度
        if (newPassword.length() < 8) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "新密码至少需要8个字符");
        }

        // 验证密码一致性
        if (!newPassword.equals(confirmPassword)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "新密码和确认密码不一致");
        }

        // 更新密码
        user.setPassword(newPassword);
        user.setUpdatedAt(LocalDateTime.now());
        authRepository.save(user);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "密码修改成功");
        
        return response;
    }

    public Map<String, Object> getCurrentUser(String username) {
        Optional<User> userOptional = authRepository.findByUsername(username);
        
        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户不存在");
        }

        User user = userOptional.get();
        
        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("email", user.getEmail());
        response.put("role", user.getRole());
        response.put("status", user.getStatus());
        
        return response;
    }
}