package com.example.demo.auth.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Base64;
import java.util.Date;

public class JwtUtil {
    
    private static final String SECRET_KEY = "dGhpc2lzYXNlY3VyZWtleXRoYXRpc2V4YWN0bHk2NHllczEydGhpc2lzYXNlY3VyZWtleXRoYXRpc2V4YWN0bHk2NHllczEydGhpc2lzYXNlY3VyZWtleXRoYXRpc2V4YWN0bHk2NHllczEy";
    private static final long EXPIRATION_TIME = 86400000; // 24小时

    public static String generateToken(String username) {
        byte[] keyBytes = Base64.getDecoder().decode(SECRET_KEY);
        
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS512, keyBytes)
                .compact();
    }

    public static String getUsernameFromToken(String token) {
        byte[] keyBytes = Base64.getDecoder().decode(SECRET_KEY);
        
        Claims claims = Jwts.parser()
                .setSigningKey(keyBytes)
                .parseClaimsJws(token)
                .getBody();
        
        return claims.getSubject();
    }

    public static boolean isTokenExpired(String token) {
        byte[] keyBytes = Base64.getDecoder().decode(SECRET_KEY);
        
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(keyBytes)
                    .parseClaimsJws(token)
                    .getBody();
            
            return claims.getExpiration().before(new Date());
        } catch (Exception e) {
            return true;
        }
    }
}