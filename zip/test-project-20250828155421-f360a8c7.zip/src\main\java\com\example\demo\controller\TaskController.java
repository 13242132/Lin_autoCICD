package com.example.demo.controller;

import com.example.demo.entity.Task;
import com.example.demo.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping
    public ResponseEntity<?> createTask(
            @RequestParam String title,
            @RequestParam(required = false) String description,
            @RequestParam LocalDateTime deadline,
            @RequestParam String priority,
            @RequestParam(required = false) String assignee) {
        
        // 验证参数
        if (title == null || title.trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("{\"error\": \"TASK_CREATION_FAILED\", \"message\": \"任务创建失败：标题为空\"}");
        }
        
        if (deadline.isBefore(LocalDateTime.now())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("{\"error\": \"TASK_CREATION_FAILED\", \"message\": \"任务创建失败：截止时间早于当前时间\"}");
        }

        try {
            Task task = taskService.createTask(title, description, deadline, priority, assignee);
            return ResponseEntity.status(HttpStatus.CREATED).body(task);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("{\"error\": \"TASK_CREATION_FAILED\", \"message\": \"任务创建失败：\" + e.getMessage()}");
        }
    }

    @GetMapping
    public ResponseEntity<?> getTasks(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) String assignee) {
        
        try {
            List<Task> tasks = taskService.getTasks(status, priority, assignee);
            return ResponseEntity.ok(tasks);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("{\"error\": \"INTERNAL_ERROR\", \"message\": \"服务器错误\"}");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTaskById(@PathVariable Long id) {
        Optional<Task> task = taskService.getTaskById(id);
        if (task.isPresent()) {
            return ResponseEntity.ok(task.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("{\"error\": \"TASK_NOT_FOUND\", \"message\": \"任务不存在\"}");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateTask(
            @PathVariable Long id,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String description,
            @RequestParam(required = false) LocalDateTime deadline,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) String assignee,
            @RequestParam(required = false) String status) {
        
        try {
            Task updatedTask = taskService.updateTask(id, title, description, deadline, priority, assignee, status);
            if (updatedTask != null) {
                return ResponseEntity.ok(updatedTask);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("{\"error\": \"TASK_NOT_FOUND\", \"message\": \"任务不存在\"}");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("{\"error\": \"UPDATE_FAILED\", \"message\": \"更新失败\"}");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id) {
        boolean deleted = taskService.deleteTask(id);
        if (deleted) {
            return ResponseEntity.ok("{\"message\": \"任务删除成功\"}");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("{\"error\": \"TASK_NOT_FOUND\", \"message\": \"任务不存在\"}");
        }
    }
}