package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/{id}/stats")
    public ResponseEntity<?> getUserStats(@PathVariable Long id) {
        try {
            UserService.UserStats stats = userService.getUserStats(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("totalTasks", stats.getTotalTasks());
            response.put("completedTasks", stats.getCompletedTasks());
            response.put("pendingTasks", stats.getPendingTasks());
            response.put("completionRate", stats.getCompletionRate());
            
            return ResponseEntity.ok(response);
        } catch (UserService.UserNotFoundException e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "USER_NOT_FOUND");
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }
}