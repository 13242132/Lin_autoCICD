package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public UserStats getUserStats(Long id) {
        Optional<User> userOptional = userRepository.findById(id);
        if (userOptional.isEmpty()) {
            throw new UserNotFoundException("用户不存在");
        }
        
        // 模拟统计逻辑 - 实际项目中应该从TaskRepository查询相关数据
        // 这里返回模拟数据
        UserStats stats = new UserStats();
        stats.setTotalTasks(15);
        stats.setCompletedTasks(10);
        stats.setPendingTasks(5);
        stats.setCompletionRate(new BigDecimal("66.67"));
        
        return stats;
    }

    public static class UserStats {
        private Integer totalTasks;
        private Integer completedTasks;
        private Integer pendingTasks;
        private BigDecimal completionRate;

        // Getters and setters
        public Integer getTotalTasks() { return totalTasks; }
        public void setTotalTasks(Integer totalTasks) { this.totalTasks = totalTasks; }
        
        public Integer getCompletedTasks() { return completedTasks; }
        public void setCompletedTasks(Integer completedTasks) { this.completedTasks = completedTasks; }
        
        public Integer getPendingTasks() { return pendingTasks; }
        public void setPendingTasks(Integer pendingTasks) { this.pendingTasks = pendingTasks; }
        
        public BigDecimal getCompletionRate() { return completionRate; }
        public void setCompletionRate(BigDecimal completionRate) { this.completionRate = completionRate; }
    }

    public static class UserNotFoundException extends RuntimeException {
        public UserNotFoundException(String message) {
            super(message);
        }
    }
}