package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class test_project_20250828155421_f360a8c7Application {

    public static void main(String[] args) {
        SpringApplication.run(test_project_20250828155421_f360a8c7Application.class, args);
    }

}