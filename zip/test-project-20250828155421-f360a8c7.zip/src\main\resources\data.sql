-- ========================================
-- Table: user_tbl
-- 描述: 用户表
-- 字段:
-- id BIGINT 主键，自增
-- username VARCHAR(50) 用户名，不为空
-- password VARCHAR(100) 密码，不为空
-- email VARCHAR(100) 邮箱，可为空
-- role VARCHAR(20) 角色，不为空
-- status VARCHAR(20) 状态，不为空
-- created_at TIMESTAMP 创建时间，不为空
-- updated_at TIMESTAMP 更新时间，不为空
-- ========================================
MERGE INTO user_tbl (id, username, password, email, role, status, created_at, updated_at)
KEY(username)
VALUES (1, 'admin', 'admin123', 'admin@example.com', 'ADMIN', 'ACTIVE', '2025-01-01 10:00:00', '2025-01-01 10:00:00');

MERGE INTO user_tbl (id, username, password, email, role, status, created_at, updated_at)
KEY(username)
VALUES (2, 'john_doe', 'user123', 'john@example.com', 'USER', 'ACTIVE', '2025-01-02 11:00:00', '2025-01-02 11:00:00');

MERGE INTO user_tbl (id, username, password, email, role, status, created_at, updated_at)
KEY(username)
VALUES (3, 'jane_smith', 'user456', 'jane@example.com', 'USER', 'INACTIVE', '2025-01-03 12:00:00', '2025-01-03 12:00:00');

-- ========================================
-- Table: task_tbl
-- 描述: 任务表
-- 字段:
-- id BIGINT 主键，自增
-- title VARCHAR(200) 标题，不为空
-- description VARCHAR(1000) 描述，可为空
-- deadline TIMESTAMP 截止时间，不为空
-- priority VARCHAR(20) 优先级，不为空
-- assignee VARCHAR(50) 分配人，可为空
-- status VARCHAR(20) 状态，不为空
-- created_at TIMESTAMP 创建时间，不为空
-- updated_at TIMESTAMP 更新时间，不为空
-- ========================================
MERGE INTO task_tbl (id, title, description, deadline, priority, assignee, status, created_at, updated_at)
KEY(title)
VALUES (1, '系统优化', '优化数据库查询性能', '2025-02-01 18:00:00', 'HIGH', 'john_doe', 'IN_PROGRESS', '2025-01-04 09:00:00', '2025-01-04 09:00:00');

MERGE INTO task_tbl (id, title, description, deadline, priority, assignee, status, created_at, updated_at)
KEY(title)
VALUES (2, '前端页面修复', '修复登录页面响应问题', '2025-01-20 17:00:00', 'MEDIUM', 'jane_smith', 'COMPLETED', '2025-01-05 10:00:00', '2025-01-05 10:00:00');

-- ========================================
-- Table: comment_tbl
-- 描述: 评论表
-- 字段:
-- id BIGINT 主键，自增
-- content VARCHAR(500) 内容，不为空
-- author VARCHAR(50) 作者，不为空
-- task_id BIGINT 关联任务ID，不为空
-- created_at TIMESTAMP 创建时间，不为空
-- ========================================
MERGE INTO comment_tbl (id, content, author, task_id, created_at)
KEY(task_id, author)
VALUES (1, '已优化部分查询语句', 'john_doe', 1, '2025-01-05 14:00:00');

MERGE INTO comment_tbl (id, content, author, task_id, created_at)
KEY(task_id, author)
VALUES (2, '页面已修复，请测试', 'jane_smith', 2, '2025-01-06 15:00:00');

-- ========================================
-- Table: team_tbl
-- 描述: 团队表
-- 字段:
-- id BIGINT 主键，自增
-- name VARCHAR(100) 名称，不为空
-- description VARCHAR(500) 描述，可为空
-- created_at TIMESTAMP 创建时间，不为空
-- ========================================
MERGE INTO team_tbl (id, name, description, created_at)
KEY(name)
VALUES (1, '开发团队A', '负责核心系统开发', '2025-01-01 08:00:00');

MERGE INTO team_tbl (id, name, description, created_at)
KEY(name)
VALUES (2, '测试团队B', '负责产品测试', '2025-01-02 08:30:00');

-- ========================================
-- Table: team_member_tbl
-- 描述: 团队成员关联表
-- 字段:
-- team_id BIGINT 团队ID，外键
-- member_name VARCHAR(50) 成员名称，不为空
-- ========================================
MERGE INTO team_member_tbl (team_id, member_name)
KEY(team_id, member_name)
VALUES (1, 'john_doe');

MERGE INTO team_member_tbl (team_id, member_name)
KEY(team_id, member_name)
VALUES (1, 'jane_smith');

MERGE INTO team_member_tbl (team_id, member_name)
KEY(team_id, member_name)
VALUES (2, 'alice');

-- ========================================
-- Table: notification_tbl
-- 描述: 通知表
-- 字段:
-- id BIGINT 主键，自增
-- title VARCHAR(200) 标题，不为空
-- content VARCHAR(500) 内容，不为空
-- recipient VARCHAR(50) 接收人，不为空
-- type VARCHAR(20) 类型，不为空
-- is_read BOOLEAN 是否已读，默认false
-- created_at TIMESTAMP 创建时间，不为空
-- ========================================
MERGE INTO notification_tbl (id, title, content, recipient, type, is_read, created_at)
KEY(recipient, title)
VALUES (1, '任务更新通知', '系统优化任务有新的评论', 'john_doe', 'TASK', false, '2025-01-05 14:10:00');

MERGE INTO notification_tbl (id, title, content, recipient, type, is_read, created_at)
KEY(recipient, title)
VALUES (2, '任务完成通知', '前端页面修复任务已完成', 'admin', 'TASK', true, '2025-01-06 15:30:00');