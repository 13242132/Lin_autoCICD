basicInfo: 用户注册 POST /api/auth/register - 新用户注册
requestParams: { "username": "String, 6-20位字母数字", "email": "String, 邮箱格式", "password": "String, 最少6字符含大小写与数字" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","username":"String","email":"String","createdAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"REGISTER_FAILED","message":"用户名或邮箱已被占用" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

basicInfo: 用户登录 POST /api/auth/login - 用户登录
requestParams: { "usernameOrEmail": "String, 用户名或邮箱", "password": "String, 密码" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "token":"String","userId":"Long","username":"String" } },
  "error": { "status_code": 401, "response_body": { "error":"LOGIN_FAILED","message":"用户名或密码错误" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

basicInfo: 获取新闻列表 GET /api/news - 查询新闻列表
requestParams: { "category": "String, 可选 - 新闻分类", "page": "Integer, 可选 - 页码", "size": "Integer, 可选 - 每页数量" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","title":"String","source":"String","publishedAt":"String","category":"String","summary":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: NewsController
basePath: /api/news

---API_SEPARATOR---

basicInfo: 获取新闻详情 GET /api/news/{id} - 获取单条新闻详情
requestParams: { "id": "Long, 路径参数 - 新闻ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","title":"String","source":"String","publishedAt":"String","content":"String","category":"String" } },
  "error": { "status_code": 404, "response_body": { "error":"NOT_FOUND","message":"新闻不存在" } }
}
apiType: entity_related
controller: NewsController
basePath: /api/news

---API_SEPARATOR---

basicInfo: 获取用户订阅 GET /api/subscriptions - 获取用户订阅的主题
requestParams: { "userId": "Long, 可选 - 用户ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","userId":"Long","topicName":"String","subscribedAt":"String" } ] },
  "error": { "status_code": 401, "response_body": { "error":"UNAUTHORIZED","message":"请先登录" } }
}
apiType: entity_related
controller: SubscriptionController
basePath: /api/subscriptions

---API_SEPARATOR---

basicInfo: 添加订阅 POST /api/subscriptions - 用户订阅主题
requestParams: { "userId": "Long, 用户ID", "topicName": "String, 主题名称" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","userId":"Long","topicName":"String","subscribedAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"SUBSCRIPTION_LIMIT","message":"最多可订阅5个主题" } }
}
apiType: entity_related
controller: SubscriptionController
basePath: /api/subscriptions

---API_SEPARATOR---

basicInfo: 取消订阅 DELETE /api/subscriptions/{id} - 用户取消订阅
requestParams: { "id": "Long, 路径参数 - 订阅ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "message":"取消订阅成功" } },
  "error": { "status_code": 404, "response_body": { "error":"NOT_FOUND","message":"订阅不存在" } }
}
apiType: entity_related
controller: SubscriptionController
basePath: /api/subscriptions

---API_SEPARATOR---

basicInfo: 获取新闻评论 GET /api/comments - 获取新闻的评论列表
requestParams: { "newsId": "Long, 新闻ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","newsId":"Long","userId":"Long","content":"String","createdAt":"String","username":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: CommentController
basePath: /api/comments

---API_SEPARATOR---

basicInfo: 添加评论 POST /api/comments - 用户添加评论
requestParams: { "newsId": "Long, 新闻ID", "userId": "Long, 用户ID", "content": "String, 评论内容" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","newsId":"Long","userId":"Long","content":"String","createdAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"COMMENT_FAILED","message":"评论失败" } }
}
apiType: entity_related
controller: CommentController
basePath: /api/comments

---API_SEPARATOR---

basicInfo: 点赞新闻 POST /api/likes - 用户点赞新闻
requestParams: { "newsId": "Long, 新闻ID", "userId": "Long, 用户ID" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","newsId":"Long","userId":"Long","createdAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"LIKE_FAILED","message":"点赞失败" } }
}
apiType: entity_related
controller: LikeController
basePath: /api/likes

---API_SEPARATOR---

basicInfo: 取消点赞 DELETE /api/likes/{id} - 用户取消点赞
requestParams: { "id": "Long, 路径参数 - 点赞ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "message":"取消点赞成功" } },
  "error": { "status_code": 404, "response_body": { "error":"NOT_FOUND","message":"点赞记录不存在" } }
}
apiType: entity_related
controller: LikeController
basePath: /api/likes

---API_SEPARATOR---

basicInfo: 获取用户信息 GET /api/users/{id} - 获取用户个人信息
requestParams: { "id": "Long, 路径参数 - 用户ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","username":"String","email":"String","createdAt":"String","avatar":"String" } },
  "error": { "status_code": 404, "response_body": { "error":"NOT_FOUND","message":"用户不存在" } }
}
apiType: entity_related
controller: UserController
basePath: /api/users

---API_SEPARATOR---

basicInfo: 更新用户信息 PUT /api/users/{id} - 更新用户个人信息
requestParams: { "id": "Long, 路径参数 - 用户ID", "username": "String, 用户名", "email": "String, 邮箱", "avatar": "String, 可选 - 头像URL" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","username":"String","email":"String","avatar":"String","updatedAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"UPDATE_FAILED","message":"更新失败" } }
}
apiType: entity_related
controller: UserController
basePath: /api/users

---API_SEPARATOR---

basicInfo: 获取所有主题 GET /api/topics - 获取所有可订阅的主题
requestParams: {}
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","name":"String","description":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: TopicController
basePath: /api/topics

---API_SEPARATOR---

basicInfo: 获取阅读历史 GET /api/history - 获取用户阅读历史
requestParams: { "userId": "Long, 用户ID", "page": "Integer, 可选 - 页码", "size": "Integer, 可选 - 每页数量" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","userId":"Long","newsId":"Long","readAt":"String","newsTitle":"String" } ] },
  "error": { "status_code": 401, "response_body": { "error":"UNAUTHORIZED","message":"请先登录" } }
}
apiType: entity_related
controller: HistoryController
basePath: /api/history

---API_SEPARATOR---

---ENTITY_LIST_START---
@Table(name = "user_tbl")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "username", nullable = false, length = 20)
    private String username;

    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Column(name = "password", nullable = false, length = 100)
    private String password;

    @Column(name = "avatar", length = 255)
    private String avatar;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime updatedAt;
}

@Table(name = "news_tbl")
public class News {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, length = 200)
    private String title;

    @Column(name = "source", nullable = false, length = 100)
    private String source;

    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    @Column(name = "summary", length = 500)
    private String summary;

    @Column(name = "category", length = 50)
    private String category;

    @Column(name = "published_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime publishedAt;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "topic_tbl")
public class Topic {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", nullable = false, length = 50)
    private String name;

    @Column(name = "description", length = 200)
    private String description;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "subscription_tbl")
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "topic_name", nullable = false, length = 50)
    private String topicName;

    @Column(name = "subscribed_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime subscribedAt = LocalDateTime.now();
}

@Table(name = "comment_tbl")
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "news_id", nullable = false)
    private Long newsId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "content", nullable = false, length = 1000)
    private String content;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "like_tbl")
public class Like {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "news_id", nullable = false)
    private Long newsId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "history_tbl")
public class History {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "news_id", nullable = false)
    private Long newsId;

    @Column(name = "read_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime readAt = LocalDateTime.now();
}

@Table(name = "audit_log_tbl")
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "action", nullable = false, length = 100)
    private String action;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "ip_address", length = 45)
    private String ipAddress;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}
---ENTITY_LIST_END---