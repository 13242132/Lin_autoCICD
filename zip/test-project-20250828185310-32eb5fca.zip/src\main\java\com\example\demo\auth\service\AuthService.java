package com.example.demo.auth.service;

import com.example.demo.auth.repository.AuthRepository;
import com.example.demo.auth.util.JwtUtil;
import com.example.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private AuthRepository authRepository;

    public Map<String, Object> register(String username, String email, String password) {
        // 检查用户名是否已存在
        Optional<User> existingUserByUsername = authRepository.findByUsername(username);
        if (existingUserByUsername.isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "用户名已被占用");
        }

        // 检查邮箱是否已存在
        Optional<User> existingUserByEmail = authRepository.findByEmail(email);
        if (existingUserByEmail.isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "邮箱已被占用");
        }

        // 创建新用户
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password); // 注意：实际项目中应该加密密码
        user.setCreatedAt(LocalDateTime.now());

        User savedUser = authRepository.save(user);

        Map<String, Object> response = new HashMap<>();
        response.put("id", savedUser.getId());
        response.put("username", savedUser.getUsername());
        response.put("email", savedUser.getEmail());
        response.put("createdAt", savedUser.getCreatedAt().toString());

        return response;
    }

    public Map<String, Object> login(String usernameOrEmail, String password) {
        // 查找用户（通过用户名或邮箱）
        Optional<User> userOptional = authRepository.findByUsernameOrEmail(usernameOrEmail, usernameOrEmail);
        
        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户名或密码错误");
        }

        User user = userOptional.get();
        
        // 验证密码（注意：实际项目中应该使用加密验证）
        if (!user.getPassword().equals(password)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户名或密码错误");
        }

        // 生成token
        String token = JwtUtil.generateToken(user.getUsername());

        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("userId", user.getId());
        response.put("username", user.getUsername());

        return response;
    }

    public Map<String, Object> getCurrentUser(String username) {
        Optional<User> userOptional = authRepository.findByUsername(username);
        
        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "用户不存在");
        }

        User user = userOptional.get();
        
        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("email", user.getEmail());
        response.put("createdAt", user.getCreatedAt().toString());

        return response;
    }
}