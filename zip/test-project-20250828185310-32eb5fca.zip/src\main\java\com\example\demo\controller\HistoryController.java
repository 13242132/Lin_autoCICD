package com.example.demo.controller;

import com.example.demo.service.HistoryService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;

@RestController
@RequestMapping("/api/history")
public class HistoryController {
    
    private final HistoryService historyService;
    
    public HistoryController(HistoryService historyService) {
        this.historyService = historyService;
    }
    
    @GetMapping
    public ResponseEntity<?> getHistory(
            @RequestParam Long userId,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        
        try {
            // 模拟用户认证检查（简化处理）
            if (userId == null) {
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("error", "UNAUTHORIZED");
                errorResponse.put("message", "请先登录");
                return ResponseEntity.status(401).body(errorResponse);
            }
            
            Page<Object> historyPage = historyService.getHistoryByUserId(userId, page, size);
            return ResponseEntity.ok(historyPage.getContent());
            
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "INTERNAL_ERROR");
            errorResponse.put("message", "服务器内部错误");
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
}