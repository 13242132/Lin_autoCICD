package com.example.demo.controller;

import com.example.demo.entity.Like;
import com.example.demo.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/likes")
public class LikeController {

    @Autowired
    private LikeService likeService;

    @PostMapping
    public ResponseEntity<?> createLike(@RequestParam Long newsId, @RequestParam Long userId) {
        try {
            Like like = likeService.createLike(newsId, userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("id", like.getId());
            response.put("newsId", like.getNewsId());
            response.put("userId", like.getUserId());
            response.put("createdAt", like.getCreatedAt().toString());
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "LIKE_FAILED");
            errorResponse.put("message", "点赞失败");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteLike(@PathVariable Long id) {
        if (!likeService.existsById(id)) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "NOT_FOUND");
            errorResponse.put("message", "点赞记录不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
        
        likeService.deleteLike(id);
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "取消点赞成功");
        return ResponseEntity.ok(response);
    }
}