package com.example.demo.controller;

import com.example.demo.entity.News;
import com.example.demo.service.NewsService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import java.util.*;

@RestController
@RequestMapping("/api/news")
public class NewsController {

    private final NewsService newsService;

    public NewsController(NewsService newsService) {
        this.newsService = newsService;
    }

    @GetMapping
    public ResponseEntity<?> getNewsList(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        
        try {
            Page<News> newsPage = newsService.getNewsList(category, page, size);
            return ResponseEntity.ok(newsPage.getContent());
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ErrorResponse("INTERNAL_ERROR", "服务器错误"));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getNewsDetail(@PathVariable Long id) {
        try {
            Optional<News> news = newsService.getNewsDetail(id);
            if (news.isPresent()) {
                return ResponseEntity.ok(news.get());
            } else {
                return ResponseEntity.notFound()
                        .body(new ErrorResponse("NOT_FOUND", "新闻不存在"));
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ErrorResponse("INTERNAL_ERROR", "服务器错误"));
        }
    }

    // 错误响应类
    public static class ErrorResponse {
        private String error;
        private String message;

        public ErrorResponse(String error, String message) {
            this.error = error;
            this.message = message;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}