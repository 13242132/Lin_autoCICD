package com.example.demo.service;

import com.example.demo.entity.History;
import com.example.demo.entity.News;
import com.example.demo.repository.HistoryRepository;
import com.example.demo.repository.NewsRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.time.*;

@Service
public class HistoryService {
    
    private final HistoryRepository historyRepository;
    private final NewsRepository newsRepository;
    
    public HistoryService(HistoryRepository historyRepository, NewsRepository newsRepository) {
        this.historyRepository = historyRepository;
        this.newsRepository = newsRepository;
    }
    
    public Page<Object> getHistoryByUserId(Long userId, Integer page, Integer size) {
        // 设置分页参数，默认值处理
        int pageNumber = page != null ? page : 0;
        int pageSize = size != null ? size : 10;
        
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<History> historyPage = historyRepository.findByUserId(userId, pageable);
        
        // 转换为包含新闻标题的DTO
        return historyPage.map(history -> {
            Optional<News> newsOptional = newsRepository.findById(history.getNewsId());
            String newsTitle = newsOptional.map(News::getTitle).orElse("未知标题");
            
            return new Object() {
                public Long id = history.getId();
                public Long userId = history.getUserId();
                public Long newsId = history.getNewsId();
                public String readAt = history.getReadAt().toString();
                public String newsTitle = newsTitle;
            };
        });
    }
}