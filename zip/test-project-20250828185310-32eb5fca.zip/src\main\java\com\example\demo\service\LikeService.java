package com.example.demo.service;

import com.example.demo.entity.Like;
import com.example.demo.repository.LikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@Transactional
public class LikeService {

    @Autowired
    private LikeRepository likeRepository;

    public Like createLike(Long newsId, Long userId) {
        Like like = new Like();
        like.setNewsId(newsId);
        like.setUserId(userId);
        like.setCreatedAt(LocalDateTime.now());
        return likeRepository.save(like);
    }

    public void deleteLike(Long id) {
        likeRepository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return likeRepository.existsById(id);
    }
}