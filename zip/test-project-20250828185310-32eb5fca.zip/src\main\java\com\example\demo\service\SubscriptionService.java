package com.example.demo.service;

import com.example.demo.entity.Subscription;
import com.example.demo.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.*;

@Service
public class SubscriptionService {
    
    @Autowired
    private SubscriptionRepository subscriptionRepository;
    
    public List<Subscription> getSubscriptionsByUserId(Long userId) {
        if (userId == null) {
            // 使用默认用户ID 1
            return subscriptionRepository.findByUserId(1L);
        }
        return subscriptionRepository.findByUserId(userId);
    }
    
    public Subscription createSubscription(Long userId, String topicName) {
        // 检查用户是否已经订阅该主题
        List<Subscription> existingSubscriptions = subscriptionRepository.findByUserIdAndTopicName(userId, topicName);
        if (!existingSubscriptions.isEmpty()) {
            throw new RuntimeException("用户已订阅该主题");
        }
        
        // 检查用户订阅数量是否超过限制（5个）
        long subscriptionCount = subscriptionRepository.countByUserId(userId);
        if (subscriptionCount >= 5) {
            throw new RuntimeException("最多可订阅5个主题");
        }
        
        Subscription subscription = new Subscription();
        subscription.setUserId(userId);
        subscription.setTopicName(topicName);
        
        return subscriptionRepository.save(subscription);
    }
    
    public void deleteSubscription(Long id) {
        Optional<Subscription> subscriptionOptional = subscriptionRepository.findById(id);
        if (subscriptionOptional.isEmpty()) {
            throw new RuntimeException("订阅不存在");
        }
        subscriptionRepository.deleteById(id);
    }
}