-- ========================================
-- Table: user_tbl
-- 描述: 用户表
-- 字段:
-- id BIGINT 主键，自增
-- username VARCHAR(20) NOT NULL 用户名
-- email VARCHAR(100) NOT NULL 邮箱
-- password VARCHAR(100) NOT NULL 密码
-- avatar VARCHAR(255) NULL 头像URL
-- created_at TIMESTAMP NOT NULL 创建时间
-- updated_at TIMESTAMP NULL 更新时间
-- ========================================
MERGE INTO user_tbl (username, email, password, avatar, created_at, updated_at)
KEY(username)
VALUES ('admin', 'admin@example.com', 'admin123', 'https://example.com/avatar_admin.jpg', '2025-01-01 10:00:00', '2025-01-02 15:00:00');

MERGE INTO user_tbl (username, email, password, avatar, created_at, updated_at)
KEY(username)
VALUES ('user1', 'user1@example.com', 'user123', 'https://example.com/avatar_user1.jpg', '2025-01-03 09:00:00', NULL);

MERGE INTO user_tbl (username, email, password, avatar, created_at, updated_at)
KEY(username)
VALUES ('user2', 'user2@example.com', 'user456', NULL, '2025-01-04 14:00:00', '2025-01-05 16:30:00');

-- ========================================
-- Table: news_tbl
-- 描述: 新闻表
-- 字段:
-- id BIGINT 主键，自增
-- title VARCHAR(200) NOT NULL 标题
-- source VARCHAR(100) NOT NULL 来源
-- content TEXT NOT NULL 内容
-- summary VARCHAR(500) NULL 摘要
-- category VARCHAR(50) NULL 分类
-- published_at TIMESTAMP NOT NULL 发布时间
-- created_at TIMESTAMP NOT NULL 创建时间
-- ========================================
MERGE INTO news_tbl (title, source, content, summary, category, published_at, created_at)
KEY(title)
VALUES ('全球气候变化会议召开', '新华社', '详细描述气候变化会议内容...', '气候变化会议在巴黎召开，多国代表出席', '国际新闻', '2025-01-05 12:00:00', '2025-01-05 13:00:00');

MERGE INTO news_tbl (title, source, content, summary, category, published_at, created_at)
KEY(title)
VALUES ('科技创新推动经济发展', '科技日报', '人工智能、大数据等技术推动经济转型...', '科技创新成为经济增长新引擎', '科技新闻', '2025-01-06 10:00:00', '2025-01-06 11:00:00');

-- ========================================
-- Table: topic_tbl
-- 描述: 话题表
-- 字段:
-- id BIGINT 主键，自增
-- name VARCHAR(50) NOT NULL 名称
-- description VARCHAR(200) NULL 描述
-- created_at TIMESTAMP NOT NULL 创建时间
-- ========================================
MERGE INTO topic_tbl (name, description, created_at)
KEY(name)
VALUES ('气候变化', '关于全球气候变化的讨论', '2025-01-01 10:00:00');

MERGE INTO topic_tbl (name, description, created_at)
KEY(name)
VALUES ('人工智能', 'AI 技术发展与应用', '2025-01-02 11:00:00');

-- ========================================
-- Table: subscription_tbl
-- 描述: 用户订阅话题表
-- 字段:
-- id BIGINT 主键，自增
-- user_id BIGINT NOT NULL 用户ID
-- topic_name VARCHAR(50) NOT NULL 话题名称
-- subscribed_at TIMESTAMP NOT NULL 订阅时间
-- ========================================
MERGE INTO subscription_tbl (user_id, topic_name, subscribed_at)
KEY(user_id, topic_name)
VALUES (1, '气候变化', '2025-01-03 14:00:00');

MERGE INTO subscription_tbl (user_id, topic_name, subscribed_at)
KEY(user_id, topic_name)
VALUES (2, '人工智能', '2025-01-04 16:00:00');

-- ========================================
-- Table: comment_tbl
-- 描述: 新闻评论表
-- 字段:
-- id BIGINT 主键，自增
-- news_id BIGINT NOT NULL 新闻ID
-- user_id BIGINT NOT NULL 用户ID
-- content VARCHAR(1000) NOT NULL 评论内容
-- created_at TIMESTAMP NOT NULL 创建时间
-- ========================================
MERGE INTO comment_tbl (news_id, user_id, content, created_at)
KEY(news_id, user_id)
VALUES (1, 1, '非常好的新闻，信息全面。', '2025-01-06 15:00:00');

MERGE INTO comment_tbl (news_id, user_id, content, created_at)
KEY(news_id, user_id)
VALUES (2, 2, '期待更多人工智能的进展！', '2025-01-07 10:00:00');

-- ========================================
-- Table: like_tbl
-- 描述: 新闻点赞表
-- 字段:
-- id BIGINT 主键，自增
-- news_id BIGINT NOT NULL 新闻ID
-- user_id BIGINT NOT NULL 用户ID
-- created_at TIMESTAMP NOT NULL 创建时间
-- ========================================
MERGE INTO like_tbl (news_id, user_id, created_at)
KEY(news_id, user_id)
VALUES (1, 1, '2025-01-07 11:00:00');

MERGE INTO like_tbl (news_id, user_id, created_at)
KEY(news_id, user_id)
VALUES (2, 2, '2025-01-08 09:00:00');

-- ========================================
-- Table: history_tbl
-- 描述: 阅读历史表
-- 字段:
-- id BIGINT 主键，自增
-- user_id BIGINT NOT NULL 用户ID
-- news_id BIGINT NOT NULL 新闻ID
-- read_at TIMESTAMP NOT NULL 阅读时间
-- ========================================
MERGE INTO history_tbl (user_id, news_id, read_at)
KEY(user_id, news_id)
VALUES (1, 1, '2025-01-08 10:00:00');

MERGE INTO history_tbl (user_id, news_id, read_at)
KEY(user_id, news_id)
VALUES (2, 2, '2025-01-09 14:00:00');

-- ========================================
-- Table: audit_log_tbl
-- 描述: 审计日志表
-- 字段:
-- id BIGINT 主键，自增
-- user_id BIGINT NULL 用户ID
-- action VARCHAR(100) NOT NULL 操作行为
-- description VARCHAR(500) NULL 描述
-- ip_address VARCHAR(45) NULL IP地址
-- created_at TIMESTAMP NOT NULL 创建时间
-- ========================================
MERGE INTO audit_log_tbl (user_id, action, description, ip_address, created_at)
KEY(user_id, action, created_at)
VALUES (1, '登录成功', '用户 admin 登录系统', '192.168.1.1', '2025-01-10 08:00:00');

MERGE INTO audit_log_tbl (user_id, action, description, ip_address, created_at)
KEY(user_id, action, created_at)
VALUES (2, '发布评论', '用户 user1 发布了新闻评论', '192.168.1.2', '2025-01-11 12:00:00');