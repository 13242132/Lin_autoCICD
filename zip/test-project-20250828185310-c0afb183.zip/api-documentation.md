```
basicInfo: 用户注册 POST /api/auth/register - 新用户注册账号
requestParams: { "username": "String", "password": "String", "confirmPassword": "String" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","username":"String","createdAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"REGISTER_FAILED","message":"注册失败" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

basicInfo: 用户登录 POST /api/auth/login - 用户登录系统
requestParams: { "username": "String", "password": "String" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "token":"String","userInfo":{ "id":"Long","username":"String" } } },
  "error": { "status_code": 401, "response_body": { "error":"LOGIN_FAILED","message":"用户名或密码错误" } }
}
apiType: auth_related
controller: AuthController
basePath: /api/auth

---API_SEPARATOR---

basicInfo: 创建任务 POST /api/tasks - 新建任务并分配
requestParams: { "title": "String", "description": "String", "priority": "String", "dueDate": "String", "assignee": "String" }
responseParams: {
  "success": { "status_code": 201, "response_body": { "id":"Long","title":"String","description":"String","priority":"String","dueDate":"String","assignee":"String","status":"String","createdAt":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"CREATE_TASK_FAILED","message":"任务创建失败" } }
}
apiType: entity_related
controller: TaskController
basePath: /api/tasks

---API_SEPARATOR---

basicInfo: 获取任务列表 GET /api/tasks - 查询所有任务
requestParams: { "status": "String, 可选 - 任务状态", "assignee": "String, 可选 - 指派人" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","title":"String","priority":"String","dueDate":"String","assignee":"String","status":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: TaskController
basePath: /api/tasks

---API_SEPARATOR---

basicInfo: 获取任务详情 GET /api/tasks/{id} - 获取单个任务详细信息
requestParams: { "id": "Long, 路径参数 - 任务ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","title":"String","description":"String","priority":"String","dueDate":"String","assignee":"String","status":"String","createdAt":"String" } },
  "error": { "status_code": 404, "response_body": { "error":"TASK_NOT_FOUND","message":"任务不存在" } }
}
apiType: entity_related
controller: TaskController
basePath: /api/tasks

---API_SEPARATOR---

basicInfo: 更新任务状态 PUT /api/tasks/{id}/status - 修改任务状态
requestParams: { "id": "Long, 路径参数 - 任务ID", "status": "String - 新状态" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","status":"String" } },
  "error": { "status_code": 400, "response_body": { "error":"UPDATE_STATUS_FAILED","message":"状态更新失败" } }
}
apiType: entity_related
controller: TaskController
basePath: /api/tasks

---API_SEPARATOR---

basicInfo: 获取用户列表 GET /api/users - 查询所有用户
requestParams: { "role": "String, 可选 - 用户角色" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","username":"String","createdAt":"String","role":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: UserController
basePath: /api/users

---API_SEPARATOR---

basicInfo: 获取通知列表 GET /api/notifications - 获取用户通知
requestParams: { "userId": "Long, 可选 - 用户ID", "read": "Boolean, 可选 - 是否已读" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","title":"String","message":"String","createdAt":"String","read":"Boolean" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: NotificationController
basePath: /api/notifications

---API_SEPARATOR---

basicInfo: 标记通知已读 PUT /api/notifications/{id}/read - 标记单个通知为已读
requestParams: { "id": "Long, 路径参数 - 通知ID" }
responseParams: {
  "success": { "status_code": 200, "response_body": { "id":"Long","read":"Boolean" } },
  "error": { "status_code": 404, "response_body": { "error":"NOTIFICATION_NOT_FOUND","message":"通知不存在" } }
}
apiType: entity_related
controller: NotificationController
basePath: /api/notifications

---API_SEPARATOR---

basicInfo: 获取审计日志 GET /api/audit-logs - 查询系统操作日志
requestParams: { "action": "String, 可选 - 操作类型", "startTime": "String, 可选 - 开始时间", "endTime": "String, 可选 - 结束时间" }
responseParams: {
  "success": { "status_code": 200, "response_body": [ { "id":"Long","action":"String","userId":"Long","details":"String","createdAt":"String" } ] },
  "error": { "status_code": 500, "response_body": { "error":"INTERNAL_ERROR","message":"服务器错误" } }
}
apiType: entity_related
controller: AuditLogController
basePath: /api/audit-logs

---API_SEPARATOR---

---ENTITY_LIST_START---
@Table(name = "user_tbl")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "username", nullable = false, length = 50, unique = true)
    private String username;

    @Column(name = "password", nullable = false, length = 100)
    private String password;

    @Column(name = "role", nullable = false, length = 20)
    private String role;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "task_tbl")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, length = 200)
    private String title;

    @Column(name = "description", length = 1000)
    private String description;

    @Column(name = "priority", nullable = false, length = 10)
    private String priority;

    @Column(name = "due_date", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime dueDate;

    @Column(name = "assignee", nullable = false, length = 50)
    private String assignee;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "notification_tbl")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title", nullable = false, length = 100)
    private String title;

    @Column(name = "message", nullable = false, length = 500)
    private String message;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "read", nullable = false)
    private Boolean read = false;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}

@Table(name = "audit_log_tbl")
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "action", nullable = false, length = 50)
    private String action;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "details", length = 1000)
    private String details;

    @Column(name = "created_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createdAt = LocalDateTime.now();
}
---ENTITY_LIST_END---
```