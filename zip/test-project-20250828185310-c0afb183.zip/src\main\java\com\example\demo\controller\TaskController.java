package com.example.demo.controller;

import com.example.demo.entity.Task;
import com.example.demo.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping
    public ResponseEntity<?> createTask(
            @RequestParam String title,
            @RequestParam String description,
            @RequestParam String priority,
            @RequestParam String dueDate,
            @RequestParam String assignee) {
        try {
            Task task = taskService.createTask(title, description, priority, dueDate, assignee);
            return ResponseEntity.status(HttpStatus.CREATED).body(task);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("{\"error\":\"CREATE_TASK_FAILED\",\"message\":\"任务创建失败\"}");
        }
    }

    @GetMapping
    public ResponseEntity<?> getTasks(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String assignee) {
        try {
            List<Task> tasks = taskService.getAllTasks(status, assignee);
            return ResponseEntity.ok(tasks);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("{\"error\":\"INTERNAL_ERROR\",\"message\":\"服务器错误\"}");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTask(@PathVariable Long id) {
        Optional<Task> task = taskService.getTaskById(id);
        if (task.isPresent()) {
            return ResponseEntity.ok(task.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("{\"error\":\"TASK_NOT_FOUND\",\"message\":\"任务不存在\"}");
        }
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateTaskStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            Task task = taskService.updateTaskStatus(id, status);
            if (task != null) {
                return ResponseEntity.ok("{\"id\":" + task.getId() + ",\"status\":\"" + task.getStatus() + "\"}");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("{\"error\":\"UPDATE_STATUS_FAILED\",\"message\":\"状态更新失败\"}");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("{\"error\":\"UPDATE_STATUS_FAILED\",\"message\":\"状态更新失败\"}");
        }
    }
}