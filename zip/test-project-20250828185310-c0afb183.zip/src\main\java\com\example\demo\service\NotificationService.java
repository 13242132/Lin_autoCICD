package com.example.demo.service;

import com.example.demo.entity.Notification;
import com.example.demo.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    public List<Notification> getNotifications(Long userId, Boolean read) {
        if (userId != null && read != null) {
            return notificationRepository.findByUserIdAndRead(userId, read);
        } else if (userId != null) {
            return notificationRepository.findByUserId(userId);
        } else if (read != null) {
            return notificationRepository.findByRead(read);
        } else {
            return notificationRepository.findAll();
        }
    }

    public Notification markNotificationAsRead(Long id) {
        Optional<Notification> notificationOptional = notificationRepository.findById(id);
        if (notificationOptional.isPresent()) {
            Notification notification = notificationOptional.get();
            notification.setRead(true);
            return notificationRepository.save(notification);
        }
        return null;
    }
}