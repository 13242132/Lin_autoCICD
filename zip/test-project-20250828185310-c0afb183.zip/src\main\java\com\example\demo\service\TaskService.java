package com.example.demo.service;

import com.example.demo.entity.Task;
import com.example.demo.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.domain.Specification;
import jakarta.persistence.criteria.Predicate;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    public Task createTask(String title, String description, String priority, String dueDate, String assignee) {
        Task task = new Task();
        task.setTitle(title);
        task.setDescription(description);
        task.setPriority(priority);
        task.setDueDate(LocalDateTime.parse(dueDate, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        task.setAssignee(assignee);
        task.setStatus("PENDING");
        task.setCreatedAt(LocalDateTime.now());
        return taskRepository.save(task);
    }

    public List<Task> getAllTasks(String status, String assignee) {
        if (status != null && assignee != null) {
            return taskRepository.findAll((root, query, criteriaBuilder) -> 
                criteriaBuilder.and(
                    criteriaBuilder.equal(root.get("status"), status),
                    criteriaBuilder.equal(root.get("assignee"), assignee)
                )
            );
        } else if (status != null) {
            return taskRepository.findAll((root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("status"), status)
            );
        } else if (assignee != null) {
            return taskRepository.findAll((root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("assignee"), assignee)
            );
        } else {
            return taskRepository.findAll();
        }
    }

    public Optional<Task> getTaskById(Long id) {
        return taskRepository.findById(id);
    }

    public Task updateTaskStatus(Long id, String status) {
        Optional<Task> taskOptional = taskRepository.findById(id);
        if (taskOptional.isPresent()) {
            Task task = taskOptional.get();
            task.setStatus(status);
            return taskRepository.save(task);
        }
        return null;
    }
}