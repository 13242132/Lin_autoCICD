-- ========================================
-- Table: user_tbl
-- Description: 存储用户账户信息
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- username VARCHAR(50) NOT NULL UNIQUE
-- password VARCHAR(100) NOT NULL
-- role VARCHAR(20) NOT NULL
-- created_at TIMESTAMP NOT NULL
-- ========================================
MERGE INTO user_tbl (id, username, password, role, created_at)
KEY(username)
VALUES (1, 'admin', 'admin123', 'ADMIN', '2025-01-01 10:00:00');

MERGE INTO user_tbl (id, username, password, role, created_at)
KEY(username)
VALUES (2, 'john_doe', 'user123', 'USER', '2025-01-02 11:00:00');

MERGE INTO user_tbl (id, username, password, role, created_at)
KEY(username)
VALUES (3, 'jane_doe', 'user456', 'USER', '2025-01-03 12:00:00');

-- ========================================
-- Table: task_tbl
-- Description: 存储任务信息
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- title VARCHAR(200) NOT NULL
-- description VARCHAR(1000) NULL
-- priority VARCHAR(10) NOT NULL
-- due_date TIMESTAMP NOT NULL
-- assignee VARCHAR(50) NOT NULL
-- status VARCHAR(20) NOT NULL
-- created_at TIMESTAMP NOT NULL
-- ========================================
MERGE INTO task_tbl (id, title, description, priority, due_date, assignee, status, created_at)
KEY(title)
VALUES (1, 'Fix login bug', '修复用户登录失败问题', 'HIGH', '2025-01-10 18:00:00', 'john_doe', 'IN_PROGRESS', '2025-01-04 09:00:00');

MERGE INTO task_tbl (id, title, description, priority, due_date, assignee, status, created_at)
KEY(title)
VALUES (2, 'Update documentation', '更新用户手册和API文档', 'MEDIUM', '2025-01-15 17:00:00', 'jane_doe', 'TODO', '2025-01-05 10:00:00');

MERGE INTO task_tbl (id, title, description, priority, due_date, assignee, status, created_at)
KEY(title)
VALUES (3, 'Design homepage', '设计网站首页界面', 'LOW', '2025-01-20 16:00:00', 'john_doe', 'COMPLETED', '2025-01-06 11:00:00');

-- ========================================
-- Table: notification_tbl
-- Description: 存储用户通知信息
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- title VARCHAR(100) NOT NULL
-- message VARCHAR(500) NOT NULL
-- user_id BIGINT NOT NULL
-- read BOOLEAN NOT NULL DEFAULT FALSE
-- created_at TIMESTAMP NOT NULL
-- ========================================
MERGE INTO notification_tbl (id, title, message, user_id, read, created_at)
KEY(id)
VALUES (1, '任务分配通知', '您被分配了一个新任务：Fix login bug', 2, FALSE, '2025-01-04 09:30:00');

MERGE INTO notification_tbl (id, title, message, user_id, read, created_at)
KEY(id)
VALUES (2, '任务已完成', '任务 Design homepage 已完成', 3, TRUE, '2025-01-06 11:30:00');

MERGE INTO notification_tbl (id, title, message, user_id, read, created_at)
KEY(id)
VALUES (3, '系统维护通知', '系统将在今晚进行维护升级', 2, FALSE, '2025-01-07 14:00:00');

-- ========================================
-- Table: audit_log_tbl
-- Description: 存储审计日志信息
-- Fields:
-- id BIGINT AUTO_INCREMENT PRIMARY KEY
-- action VARCHAR(50) NOT NULL
-- user_id BIGINT NOT NULL
-- details VARCHAR(1000) NULL
-- created_at TIMESTAMP NOT NULL
-- ========================================
MERGE INTO audit_log_tbl (id, action, user_id, details, created_at)
KEY(id)
VALUES (1, 'LOGIN', 2, 'User john_doe logged in successfully', '2025-01-04 08:55:00');

MERGE INTO audit_log_tbl (id, action, user_id, details, created_at)
KEY(id)
VALUES (2, 'TASK_CREATED', 1, 'Admin created a new task: Fix login bug', '2025-01-04 09:15:00');

MERGE INTO audit_log_tbl (id, action, user_id, details, created_at)
KEY(id)
VALUES (3, 'TASK_UPDATED', 2, 'User john_doe updated task status to IN_PROGRESS', '2025-01-05 10:30:00');